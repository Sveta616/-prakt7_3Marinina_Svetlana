
fun main()
{
    try{
        println("Введите k")
        var k=readLine()!!.toInt()
        println("Введите l")
        var l=readLine()!!.toInt()
        println("Введите n")
        var n=readLine()!!.toInt()
        println("Введите m")
        var m=readLine()!!.toInt()
        if (k!=0) {
            when {

                (l % k == 0) -> println("k является делителем l")
                else -> println("k не является делителем l")
            }
            when {
                (n % k == 0) -> println("k является делителем n ")
                else -> println("k не является делителем n")
            }
            when {
                (m % k == 0) -> println("k является делителем m")
                else -> println("k не является делителем m")
            }
        }
        else println("на ноль делить нельзя")


    }catch(e:Exception)
    {
        println("Введите символ");
    }
}