//9var
import kotlin.math.pow
fun main()
{
    try{
    println("Введите сторону a прямоугольника")
    var a=readLine()!!.toDouble()
    println("Введите сторону b прямоугольника")
    var b=readLine()!!.toDouble()
    var p=2*(a+b)
    var s=a*b
    var c=a.pow(2)+b.pow(2)

    when
    {
        (a>=0&&b>=0)->println("Периметр="+ String.format("%.2f",p)+" "+ "Площадь="+ String.format("%.2f",s)+" " +"Длина диагонали="+ String.format("%.2f",c))
        else-> println("Число не может быть отрицательным или равно 0")
    }
    }catch(e:Exception)
    {
        println("Введите символ");
    }
}