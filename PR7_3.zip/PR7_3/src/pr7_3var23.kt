fun main()
{
    try{
       println("Введите координату x")
        var x= readLine()!!.toDouble()
        println("Введите координату y")
        var y= readLine()!!.toDouble()
        var k=x*y
        when {
            (k <= 1 || k >= -2)->println("3 график")
            (k <= 2 || k >= -1)->println("4 график")
            (k <= 1.5 || k >= 1)->println("1 график")
            (k <= 2 || k >= -1)->println("2 график")
           else-> println("точка не относится к графику")
        }
    }catch(e:Exception)
    {
        println("Введите символ");
    }
}