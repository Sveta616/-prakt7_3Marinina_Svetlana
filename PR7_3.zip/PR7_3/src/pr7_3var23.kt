fun main()
{
    try{
       println("Введите координату x1")
        var x1= readLine()!!.toDouble()
        println("Введите координату y1")
        var y1= readLine()!!.toDouble()
        var k1=x1*y1
        println("Введите координату x2")
        var x2= readLine()!!.toDouble()
        println("Введите координату y2")
        var y2= readLine()!!.toDouble()
        var k2=x2*y2
        println("Введите координату x3")
        var x3= readLine()!!.toDouble()
        println("Введите координату y3")
        var y3= readLine()!!.toDouble()
        var k3=x3*y3
        println("Введите координату x4")
        var x4= readLine()!!.toDouble()
        println("Введите координату y4")
        var y4= readLine()!!.toDouble()
        var k4=x4*y4
        when {
            (k3 <= 1 || k3 >= -2)->println("3 график")
            (k4 <= 2 || k4 >= -1)->println("4 график")
            (k1 <= 1.5 || k1 >= 1)->println("1 график")
            (k2 <= 2 || k2 >= -1)->println("2 график")
           else-> println("точка не относится к графику")
        }
    }catch(E:Exception)
    {
        println("Введите символ");
    }
}